
//ʹ����STC�����ϼ�����: www.STCMCU.com
//ʱ�ӣ�timer0

#include	"task.h"
#include "APP.h"
#include "PCA.h"
/*
void task_A()
{
	static bit flag=0;
	if(flag)
	PWMn_Update(PCA2,39000);
	else
	PWMn_Update(PCA2,35000);
	flag=~flag;
}*/
//========================================================================
//                        ���ر������� & �������
//========================================================================
static TASK_COMPONENTS Task_Comps[]=
{
//״̬  ����  ����  ����
	{0, 100, 100, task_app},				/* task 1 Period�� 5ms */
//	{0, 1000, 1000, task_A},				/* task 1 Period�� 5ms */

	/* Add new task here */
};

uint8_t Tasks_Max = sizeof(Task_Comps)/sizeof(Task_Comps[0]);

//========================================================================
// ����: Task_Handler_Callback
// ����: �����ǻص�����.
// ����: None.
// ����: None.
//========================================================================
void Task_Marks_Handler_Callback(void)
{
	uint8_t i;
	for(i=0; i<Tasks_Max; i++)
	{
		if(Task_Comps[i].TIMCount)    /* If the time is not 0 */
		{
			Task_Comps[i].TIMCount--;  /* Time counter decrement */
			if(Task_Comps[i].TIMCount == 0)  /* If time arrives */
			{
				/*Resume the timer value and try again */
				Task_Comps[i].TIMCount = Task_Comps[i].TRITime;  
				Task_Comps[i].Run = 1;    /* The task can be run */
			}
		}
	}
}

//========================================================================
// ����: Task_Pro_Handler_Callback
// ����: �������ص�����.
// ����: None.
// ����: None.
//========================================================================
void Task_Pro_Handler_Callback(void)
{
	uint8_t i;
	for(i=0; i<Tasks_Max; i++)
	{
		if(Task_Comps[i].Run) /* If task can be run */
		{
			Task_Comps[i].Run = 0;    /* Flag clear 0 */
			Task_Comps[i].TaskHook();  /* Run task */
		}
	}
}



/*************************************************************************/
/*******************************user code*********************************/
/*************************************************************************/










