#ifndef _APP_H
#define _APP_H
#include "main.h"

extern bit servo_pos;
void task_app(void);
void delay_ms(uint16_t ms);

#endif