#ifndef _MAIN_H
#define _MAIN_H

#include "Config.h"

typedef unsigned char uint8_t;
typedef unsigned int uint16_t;
typedef unsigned long uint32_t;


#endif